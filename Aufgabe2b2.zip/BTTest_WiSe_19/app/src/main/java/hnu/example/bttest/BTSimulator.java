package hnu.example.bttest;

import java.util.Random;

public class BTSimulator {
    public static int INTERVALL_MS = 1000; //simulate data every 1000ms

    public static String simulateValue() {
        Random rand = new Random();

        String prefix;
        String postfix=";";


        if (rand.nextBoolean()==true) {
            int value = rand.nextInt(7000); // Obtain a number between [0 - 149].
            prefix= "RPM";
            String aErgebnis = prefix + value + postfix;
            return aErgebnis;
        } else if(rand.nextBoolean()==true){
            double value = rand.nextInt(30); // Obtain a number between [0 - 69].
            prefix= "L";
            value = value/10;
            String bErgebnis = prefix + value + postfix;
            return bErgebnis;
        }else{
            int value = rand.nextInt(180); // Obtain a number between [0 - 149].
            prefix= "T";
            String cErgebnis = prefix + value + postfix;
            return cErgebnis;
        }

    }
}
