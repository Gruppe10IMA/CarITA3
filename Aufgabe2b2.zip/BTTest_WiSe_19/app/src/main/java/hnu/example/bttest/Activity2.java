package hnu.example.bttest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Activity2 extends AppCompatActivity implements IBTMsgClient {
    private TextView mTextView1;
    private TextView mTextView2;
    private TextView mTextView3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2);

        mTextView1 = (TextView) findViewById(R.id.textView2);
        mTextView2 = (TextView) findViewById(R.id.lambda);
        mTextView3 = (TextView) findViewById(R.id.temp);
        BTManager.addBTMsgClient(this);
    }


    @Override
    public void receiveMessage(final String msg) {
        if(msg.contains("RPM")) {
            mTextView1.setText(msg);
            mTextView2.setText("-");
            mTextView3.setText("-");
        } else if(msg.contains("L")){
            mTextView1.setText("-");
            mTextView2.setText(msg);
            mTextView3.setText("-");
        } else if(msg.contains("T")){
            mTextView3.setText(msg);
            mTextView1.setText("-");
            mTextView2.setText("-");
        } else{
            mTextView1.setText("-");
            mTextView2.setText("-");
            mTextView3.setText("-");
        }
    }

    @Override
    public void receiveConnectStatus(boolean isConnected) {
    }

    @Override
    public void handleException(Exception e) {
    }
}
